#!/usr/bin/env python3
"""แปลงไฟล์ Excel ผลตรวจพยาธิ (หลายปี) -> data/data.json และ data/data.js

ใช้งาน:  python scripts/build_data.py 2568=ไฟล์ปี68.xlsx 2569=ไฟล์ปี69.xlsx
ต้องมี:  pip install openpyxl
เพิ่มปีใหม่: ใส่คู่ ปี=ไฟล์ เพิ่มเข้าไปในคำสั่งเดียวกัน (ต้องมีทุกปีที่ต้องการแสดง)
"""
import json, sys
from datetime import date
from pathlib import Path
from openpyxl import load_workbook

# (คีย์, ชื่อไทย, ลำดับคอลัมน์ฝั่ง "จำนวน" แบบ 0-based)
SPECIES = [("hookworm", "ปากขอ", 10), ("ascaris", "ไส้เดือน", 12), ("whipworm", "แส้ม้า", 14),
           ("liver_fluke", "ใบไม้ตับ", 16), ("pinworm", "เข็มหมุด", 18), ("tapeworm", "ตืด", 20),
           ("mif", "ลำไส้ขนาดกลาง", 22), ("strongyloides", "สตรองจิลอย", 24)]
FIRST_DATA_ROW = 5   # แถวแรกของข้อมูลใน Excel (หัวตารางมี 4 แถว)


def num(v):
    return v if isinstance(v, (int, float)) and not isinstance(v, bool) else None


def ival(v):
    v = num(v)
    return None if v is None else int(round(v))


def txt(v):
    return str(v).strip() if v not in (None, "") else ""


def read_year(path, year):
    ws = load_workbook(path, data_only=True).worksheets[0]
    rows = []
    for r in ws.iter_rows(min_row=FIRST_DATA_ROW, values_only=True):
        if not txt(r[1]):
            continue
        total, sent, pos = ival(r[5]), ival(r[6]), ival(r[8])
        extras = [txt(x) for x in r[29:32] if txt(x)]
        status, reason = "ok", ""
        if any("ตัดออก" in e for e in extras):
            status, reason = "excluded", " / ".join(extras)
        elif total is None and sent is None:
            status, reason = "pending", " / ".join(extras) or "ยังไม่มีผลตรวจ"
        elif not total or not sent:
            status, reason = "excluded", " / ".join(extras) or "ไม่มีนักเรียนส่งตรวจ"
        rows.append({
            "year": year, "no": ival(r[0]), "school": txt(r[1]), "tambon": txt(r[2]),
            "amphoe": txt(r[3]), "province": txt(r[4]), "affil": txt(r[28]),
            "total": total or 0, "sent": sent or 0, "pos": pos or 0,
            "sp": {k: ival(r[i]) or 0 for k, _, i in SPECIES},
            "multi": ival(r[26]) or 0, "status": status, "reason": reason})
    return rows


def main(args):
    pairs = sorted((int(a.split("=", 1)[0]), a.split("=", 1)[1]) for a in args)
    rows, src = [], []
    for y, p in pairs:
        part = read_year(p, y)
        ok = sum(1 for x in part if x["status"] == "ok")
        print(f"ปี {y}: อ่าน {len(part)} แถว ใช้คำนวณ {ok} ไม่ใช้ {len(part) - ok}")
        rows += part
        src.append(f"{y}: {Path(p).name}")
    out = {"meta": {"source": "; ".join(src), "built": date.today().isoformat(), "years": [y for y, _ in pairs],
                    "species": [{"key": k, "label": n} for k, n, _ in SPECIES]}, "schools": rows}
    d = Path(__file__).resolve().parent.parent / "data"
    d.mkdir(exist_ok=True)
    js = json.dumps(out, ensure_ascii=False, indent=1)
    (d / "data.json").write_text(js, encoding="utf-8")
    (d / "data.js").write_text("window.DASHBOARD_DATA = " + js + ";\n", encoding="utf-8")


if __name__ == "__main__":
    if len(sys.argv) < 2 or any("=" not in a for a in sys.argv[1:]):
        sys.exit(__doc__)
    main(sys.argv[1:])
