/* ส่วนเปรียบเทียบ "ปีก่อนหน้า กับ ปีที่เลือก" — โหลดก่อน app.js; ใช้ฟังก์ชันกลางจาก app.js ตอนถูกเรียก */
function renderCompare(ALL, f, CONFIG, D) {
  const el = $("compare"), ys = D.meta.years.map(String), i = ys.indexOf(f.year);
  if (i < 1) { el.hidden = true; return; }
  const py = ys[i - 1], cy = f.year;
  const pick = (y, skipAmp) => ALL.filter((s) => String(s.year) === y && (!f.province || s.province === f.province) &&
    (skipAmp || !f.amphoe || s.amphoe === f.amphoe) && (!f.affil || s.affil === f.affil));
  const A = pick(py), B = pick(cy), ta = agg(A), tb = agg(B), pa = pct(ta.pos, ta.sent), pb = pct(tb.pos, tb.sent), d = pb - pa;
  const sg = (x) => (x > 0 ? "+" : "") + x.toFixed(1);
  const kpi = [[`${p1(pa)} → ${p1(pb)}`, `ความชุก (${d <= 0 ? "ลดลง" : "เพิ่มขึ้น"} ${Math.abs(d).toFixed(1)} จุด)`, d <= 0 ? "down" : "up"],
    [`${nf(ta.pos)} → ${nf(tb.pos)}`, "ผู้พบพยาธิ (คน)"], [`${nf(ta.sent)} → ${nf(tb.sent)}`, "ผู้ส่งตรวจ (คน)"],
    [`${p1(pct(ta.sent, ta.total))} → ${p1(pct(tb.sent, tb.total))}`, "ความครอบคลุม"],
    [`${ta.n - ta.sch} → ${tb.n - tb.sch}`, "แห่งที่ไม่พบเลย"]];
  const grp = (rows, key) => { const m = new Map(); rows.forEach((s) => m.set(s[key], [...(m.get(s[key]) || []), s])); return m; };
  const pr = (rows) => { const t = agg(rows); return pct(t.pos, t.sent); };
  const ga = grp(pick(py, true), "amphoe"), gb = grp(pick(cy, true), "amphoe");
  const amp = [...new Set([...ga.keys(), ...gb.keys()])].map((k) => ({ l: k, a: pr(ga.get(k) || []), b: pr(gb.get(k) || []) }))
    .filter((x) => x.a + x.b > 0).sort((x, y) => y.b - x.b);
  const spc = D.meta.species.map((x) => ({ l: x.label, a: pct(ta.sp[x.key] || 0, ta.sent), b: pct(tb.sp[x.key] || 0, tb.sent) }))
    .sort((x, y) => Math.max(y.a, y.b) - Math.max(x.a, x.b));
  const pair = (items) => { const mx = Math.max(1, ...items.flatMap((x) => [x.a, x.b]));
    return items.map((x) => `<li><div class="row pair"><span>${esc(x.l)}</span><span class="tp"><span class="tr"><i style="width:${(x.a / mx) * 100}%;background:var(--cp)"></i></span><span class="tr"><i style="width:${(x.b / mx) * 100}%;background:var(--cc)"></i></span></span><span class="vl">${p1(x.a)} → ${p1(x.b)}</span></div></li>`).join(""); };
  const key = (s) => s.school + "|" + s.tambon, ma = new Map(A.map((s) => [key(s), s]));
  const M = B.filter((s) => ma.has(key(s))).map((s) => { const o = ma.get(key(s)); return { s, o, x: o.prev, y: s.prev, dl: s.prev - o.prev }; });
  const big = M.filter((m) => m.s.sent >= CONFIG.minSample && m.o.sent >= CONFIG.minSample);
  const lst = (arr, cls) => arr.length ? arr.map((m, n) => `<li><button type="button" data-school="${esc(m.s.school)}"><span class="rk">${n + 1}</span><span class="nm">${esc(m.s.school)}<small>อ.${esc(m.s.amphoe)} · ${p1(m.x)} → ${p1(m.y)}</small></span><span class="pv ${cls}">${sg(m.dl)}</span></button></li>`).join("") : '<li class="hint">ไม่มีโรงเรียนที่เข้าเกณฑ์</li>';
  const imp = big.filter((m) => m.dl < 0).sort((p, q) => p.dl - q.dl).slice(0, 5), wor = big.filter((m) => m.dl > 0).sort((p, q) => q.dl - p.dl).slice(0, 5);
  const W = 420, H = 330, g = { l: 38, r: 12, t: 12, b: 36 };
  const mx = Math.max(20, Math.ceil(Math.max(0, ...M.map((m) => Math.max(m.x, m.y))) / 5) * 5);
  const X = (v) => g.l + (v / mx) * (W - g.l - g.r), Y = (v) => H - g.b - (v / mx) * (H - g.t - g.b);
  let sv = ""; for (let t = 0; t <= mx; t += mx > 40 ? 20 : 10) sv += `<line class="gl" x1="${g.l}" x2="${W - g.r}" y1="${Y(t)}" y2="${Y(t)}"/><text x="${g.l - 6}" y="${Y(t) + 4}" text-anchor="end">${t}</text><text x="${X(t)}" y="${H - g.b + 16}" text-anchor="middle">${t}</text>`;
  sv += `<line x1="${X(0)}" y1="${Y(0)}" x2="${X(mx)}" y2="${Y(mx)}" stroke="var(--mute)" stroke-dasharray="5 4"/><text x="${W - g.r}" y="${H - g.b - 8}" text-anchor="end">ใต้เส้น = ดีขึ้น</text><text x="${(W + g.l) / 2}" y="${H - 4}" text-anchor="middle">ความชุก ปี ${py} (%)</text><text x="6" y="${g.t + 2}">ปี ${cy}</text>`;
  const col = (m) => (m.dl < -0.5 ? "#14867f" : m.dl > 0.5 ? "#a8322a" : "#9aa9a4");
  sv += M.map((m, j) => `<circle data-j="${j}" cx="${X(m.x)}" cy="${Y(m.y)}" r="${Math.min(12, 3 + Math.sqrt(m.s.pos) * 1.3)}" fill="${col(m)}"/>`).join("");
  const nb = M.filter((m) => m.dl < -0.5).length, nw = M.filter((m) => m.dl > 0.5).length;
  el.hidden = false;
  el.innerHTML = `<h2 class="sec">เปรียบเทียบ ปี ${py} กับ ปี ${cy}</h2>
    <div class="kpis">${kpi.map(([b, s, c]) => `<div><b class="${c || ""}">${b}</b><span>${s}</span></div>`).join("")}</div>
    <div class="grid">
      <section class="card c6"><h2>ความชุกแยกตามอำเภอ</h2><p class="hint"><span class="dot" style="background:var(--cp)"></span> ปี ${py} &nbsp; <span class="dot" style="background:var(--cc)"></span> ปี ${cy}</p><ul class="bars">${pair(amp)}</ul></section>
      <section class="card c6"><h2>ชนิดพยาธิ (ร้อยละของผู้ส่งตรวจ)</h2><p class="hint"><span class="dot" style="background:var(--cp)"></span> ปี ${py} &nbsp; <span class="dot" style="background:var(--cc)"></span> ปี ${cy}</p><ul class="bars">${pair(spc)}</ul></section>
      <section class="card c6"><h2>โรงเรียนเดียวกัน สองปี</h2><p class="hint">จับคู่ได้ ${nf(M.length)} แห่ง · ดีขึ้น ${nb} · แย่ลง ${nw} (เกณฑ์ขยับเกิน 0.5 จุด)</p><div id="cmp-sc"><svg viewBox="0 0 ${W} ${H}" aria-hidden="true">${sv}</svg></div></section>
      <section class="card c6"><h2>เปลี่ยนแปลงมากที่สุด</h2><p class="hint">เฉพาะแห่งที่ส่งตรวจ ${CONFIG.minSample} คนขึ้นไปทั้งสองปี · จุดร้อยละ · คลิกเพื่อดูในตาราง</p>
        <h3 class="sub">ลดลงมากที่สุด</h3><ol class="top">${lst(imp, "good")}</ol><h3 class="sub">เพิ่มขึ้นมากที่สุด</h3><ol class="top">${lst(wor, "bad")}</ol></section>
    </div>`;
  const sc = $("cmp-sc"), tip = $("tip");
  sc.onpointermove = (e) => { const c = e.target.closest("circle[data-j]"); if (!c) { tip.hidden = true; return; }
    const m = M[+c.dataset.j]; tip.innerHTML = `<b>${esc(m.s.school)}</b><br>อ.${esc(m.s.amphoe)}<br>${py}: ${p1(m.x)} (${nf(m.o.pos)}/${nf(m.o.sent)})<br>${cy}: ${p1(m.y)} (${nf(m.s.pos)}/${nf(m.s.sent)})`;
    tip.hidden = false; tip.style.left = Math.min(e.clientX + 14, innerWidth - 250) + "px"; tip.style.top = e.clientY + 14 + "px"; };
  sc.onpointerleave = () => (tip.hidden = true);
  sc.onclick = (e) => { const c = e.target.closest("circle[data-j]"); if (c) toTable(M[+c.dataset.j].s.school); };
}
