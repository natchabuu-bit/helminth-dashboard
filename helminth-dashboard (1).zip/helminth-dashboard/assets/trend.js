/* แนวโน้มทุกปี 2557-2569 จากทุกชีตของ sumall (prov, agency, amp) + ชนิดพยาธิ + ข้อค้นพบอัตโนมัติ */
(function () {
  const TS = window.TIMESERIES, Y = TS.years, L = Y.length - 1;
  const PAL = ["#14867f", "#d77f2a", "#6d4c8f", "#a8322a", "#4f86a8", "#8a8f3a", "#c26b8f", "#e2b546", "#5d6f6b"];
  const el = (id) => document.getElementById(id);
  const fm = (v) => (v == null ? "–" : v.toFixed(1));
  const dims = { prov: { label: "จังหวัด", d: TS.prov }, agency: { label: "สังกัด", d: TS.agency } };
  Object.keys(TS.amp).forEach((p) => (dims["amp:" + p] = { label: "อำเภอ จ." + p, d: TS.amp[p] }));
  const st = { dim: "prov", m: "found", off: new Set() };

  const series = (d, m) => Object.keys(d.found).map((name) => ({ name, total: name === "รวม",
    v: d[m][name].map((x, i) => (d.send[name][i] === 0 ? null : x)) }));
  const spSeries = () => TS.species.names.map((name, k) => ({ name, v: Y.map((y) => (TS.species.v[y] ? TS.species.v[y][k] : null)) }));

  function chart(box, ser, key) {
    const W = 680, H = 300, m = { l: 40, r: 14, t: 14, b: 30 }, n = Y.length;
    const vals = ser.flatMap((s) => s.v).filter((v) => v != null);
    const mx = Math.max(5, Math.ceil(Math.max(...vals) / 10) * 10);
    const X = (i) => m.l + (i / (n - 1)) * (W - m.l - m.r), Yy = (v) => H - m.b - (v / mx) * (H - m.t - m.b);
    let g = "";
    for (let k = 0; k <= 4; k++) { const t = (mx / 4) * k; g += `<line class="gl" x1="${m.l}" x2="${W - m.r}" y1="${Yy(t)}" y2="${Yy(t)}"/><text x="${m.l - 6}" y="${Yy(t) + 4}" text-anchor="end">${Math.round(t)}</text>`; }
    Y.forEach((y, i) => (g += `<text x="${X(i)}" y="${H - 8}" text-anchor="middle">${String(y).slice(2)}</text>`));
    const lines = ser.map((s, k) => {
      if (st.off.has(key + s.name)) return "";
      const c = s.total ? "var(--ink)" : PAL[k % PAL.length]; let d = "", pen = false;
      s.v.forEach((v, i) => { if (v == null) { pen = false; return; } d += `${pen ? "L" : "M"}${X(i)} ${Yy(v)} `; pen = true; });
      const dots = s.v.map((v, i) => (v == null ? "" : `<circle cx="${X(i)}" cy="${Yy(v)}" r="3" fill="${c}"/>`)).join("");
      return `<path d="${d}" fill="none" stroke="${c}" stroke-width="${s.total ? 3 : 2}"${s.total ? ' stroke-dasharray="6 3"' : ""} stroke-linejoin="round"/>${dots}`;
    }).join("");
    box.innerHTML = `<svg viewBox="0 0 ${W} ${H}">${g}<line class="guide" y1="${m.t}" y2="${H - m.b}" x1="-9" x2="-9"/>${lines}</svg>`;
    box._g = { ser, X, W, m, n, key };
  }
  const legend = (ser, key) => `<div class="lg">${ser.map((s, k) => `<button type="button" class="chip${st.off.has(key + s.name) ? " off" : ""}" data-th="${key}${esc(s.name)}"><span class="dot" style="background:${s.total ? "var(--ink)" : PAL[k % PAL.length]}"></span>${esc(s.name)}</button>`).join("")}</div>`;
  function heat(ser, m) {
    const col = (v) => { if (v == null) return "";
      if (m === "found") { const b = CONFIG.bands[bandIdx(v)]; return `background:${b.color};color:${b.ink}`; }
      const t = Math.min(1, v / 100), x = (a, b) => Math.round(a + (b - a) * t);
      return `background:rgb(${x(223, 15)},${x(236, 107)},${x(235, 102)});color:${t > 0.6 ? "#fff" : "#1c2b29"}`; };
    return `<div class="scroll heat"><table><thead><tr><th></th>${Y.map((y) => `<th class="n">${y}</th>`).join("")}</tr></thead><tbody>${ser.map((s) => `<tr${s.total ? ' class="tot"' : ""}><th>${esc(s.name)}</th>${s.v.map((v) => `<td class="n" style="${col(v)}">${fm(v)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
  }

  function insights() {
    const out = [], rf = TS.prov.found["รวม"], rs = TS.prov.send["รวม"], arg = (a, f) => a.reduce((b, v, i) => (v != null && (b < 0 || f(v, a[b])) ? i : b), -1);
    const pk = arg(rf, (v, b) => v > b), lo = arg(rs, (v, b) => v < b);
    out.push(`ความชุกพยาธิรวมสูงสุดปี ${Y[pk]} (${fm(rf[pk])}%) และลดเหลือ ${fm(rf[L])}% ในปี ${Y[L]} คือลดลง ${Math.round((1 - rf[L] / rf[pk]) * 100)}%`);
    if (rf[L - 1] > rf[L - 2]) out.push(`ปี ${Y[L - 1]} ความชุกเด้งขึ้นจาก ${fm(rf[L - 2])}% (ปี ${Y[L - 2]}) เป็น ${fm(rf[L - 1])}% ก่อนลดลงอีกในปี ${Y[L]} จึงยังไม่ใช่แนวโน้มลดต่อเนื่องทุกปี`);
    out.push(`ความครอบคลุมการส่งตรวจรวมปี ${Y[L]} คือ ${fm(rs[L])}% สูงกว่าจุดต่ำสุด ${fm(rs[lo])}% (ปี ${Y[lo]}) การเทียบความชุกระหว่างปีจึงควรดูควบคู่กับความครอบคลุม`);
    const top = (dm, skipTot) => { let b = null; Object.keys(dm.found).forEach((n) => { if (skipTot && n === "รวม") return; const v = dm.found[n][L], s = dm.send[n][L]; if (v != null && s > 0 && (!b || v > b.v)) b = { n, v }; }); return b; };
    const tp = top(TS.prov, 1), ta = top(TS.agency, 1);
    let tm = null; Object.keys(TS.amp).forEach((p) => { const r = top(TS.amp[p], 1); if (r && (!tm || r.v > tm.v)) tm = { ...r, p }; });
    out.push(`ปี ${Y[L]} จังหวัดที่ความชุกสูงสุดคือ ${tp.n} (${fm(tp.v)}%) สังกัดสูงสุดคือ ${ta.n} (${fm(ta.v)}%) และอำเภอสูงสุดคือ ${tm.n} จ.${tm.p} (${fm(tm.v)}%)`);
    const sv = TS.species.v, sy = String(Y[L]), s0 = sv[sy], names = TS.species.names, dom = s0.slice(0, 8).indexOf(Math.max(...s0.slice(0, 8)));
    const ref = sv[String(Y[L - 2])], rise = s0.slice(0, 8).map((v, k) => v - ref[k]), rk = rise.indexOf(Math.max(...rise));
    out.push(`พยาธิที่พบมากที่สุดปี ${sy} คือ${names[dom]} (${fm(s0[dom])}% ของผู้พบพยาธิ) ส่วน${names[rk]}เพิ่มขึ้นมากที่สุดเมื่อเทียบกับปี ${Y[L - 2]} (${rise[rk] >= 0 ? "+" : ""}${rise[rk].toFixed(1)} จุด)`);
    const S = (window.DASHBOARD_DATA && window.DASHBOARD_DATA.schools || []).filter((s) => s.status === "ok");
    const yr = (y) => S.filter((s) => s.year === y), z = (y) => yr(y).filter((s) => s.pos === 0).length;
    if (yr(2568).length && yr(2569).length) {
      out.push(`ระดับโรงเรียน: แห่งที่ไม่พบพยาธิเลยเพิ่มจาก ${z(2568)} เป็น ${z(2569)} แห่ง (จาก ${yr(2569).length} แห่ง)`);
      const r = yr(2569).slice().sort((a, b) => b.pos - a.pos), tot = r.reduce((a, s) => a + s.pos, 0), t10 = r.slice(0, 10).reduce((a, s) => a + s.pos, 0);
      out.push(`ผู้พบพยาธิปี 2569 กระจุกตัว: 10 โรงเรียนแรกมีผู้พบ ${t10} จาก ${tot} คน (${Math.round((t10 / tot) * 100)}%) จึงควรเน้นมาตรการในกลุ่มนี้ก่อน`);
    }
    const over = []; Object.keys(TS.amp).forEach((p) => Object.keys(TS.amp[p].send).forEach((n) => TS.amp[p].send[n].forEach((v, i) => { if (v > 100) over.push(`${n} จ.${p} ปี ${Y[i]} (${v}%)`); })));
    if (over.length) out.push(`ข้อควรตรวจสอบ: ความครอบคลุมเกิน 100% ที่ ${over.join(", ")} อาจเป็นความคลาดเคลื่อนของข้อมูลต้นทาง`);
    return out;
  }

  function render() {
    const dm = dims[st.dim], ser = series(dm.d, st.m), sp = spSeries();
    const opts = Object.keys(dims).map((k) => `<option value="${esc(k)}"${k === st.dim ? " selected" : ""}>${esc(dims[k].label)}</option>`).join("");
    el("trend").innerHTML = `<h2 class="sec">แนวโน้มทุกปี ${Y[0]}–${Y[L]} (รวมทุกชีตของ sumall)</h2>
      <section class="card"><h2>ข้อค้นพบสำคัญ</h2><ul class="ins">${insights().map((t) => `<li>${esc(t)}</li>`).join("")}</ul></section>
      <section class="card"><h2>เทียบตามมิติ ทุกปี</h2>
        <div class="ctl"><label>มิติ <select id="t-dim">${opts}</select></label>
          <button type="button" class="chip${st.m === "found" ? " on" : ""}" data-tm="found">ความชุก</button>
          <button type="button" class="chip${st.m === "send" ? " on" : ""}" data-tm="send">ความครอบคลุมการส่งตรวจ</button></div>
        <p class="hint">เส้นประหนาแสดงค่ารวม · คลิกชื่อเพื่อซ่อน/แสดงเส้น · ชี้กราฟเพื่อดูค่าแต่ละปี · ช่องว่าง (–) คือไม่มีข้อมูลหรือไม่มีโรงเรียนในปีนั้น</p>
        <div class="tchart" id="tc1"></div>${legend(ser, "a")}${heat(ser, st.m)}</section>
      <section class="card"><h2>ชนิดพยาธิ (ร้อยละของผู้พบพยาธิ)</h2><p class="hint">ผลรวมเกิน 100% ได้ เพราะเด็กบางคนพบหลายชนิด</p>
        <div class="tchart" id="tc2"></div>${legend(sp, "b")}${heat(sp, "share")}</section>`;
    chart(el("tc1"), ser, "a"); chart(el("tc2"), sp, "b");
  }

  function setup() {
    const box = el("trend"), tip = el("tip");
    box.addEventListener("click", (e) => {
      const b = e.target.closest("button"); if (!b) return;
      if (b.dataset.tm) st.m = b.dataset.tm; else if (b.dataset.th) st.off.has(b.dataset.th) ? st.off.delete(b.dataset.th) : st.off.add(b.dataset.th); else return;
      render();
    });
    box.addEventListener("change", (e) => { if (e.target.id === "t-dim") { st.dim = e.target.value; render(); } });
    box.addEventListener("pointermove", (e) => {
      const c = e.target.closest(".tchart"), svg = c && c.querySelector("svg"); if (!c || !c._g || !svg) { tip.hidden = true; return; }
      const g = c._g, r = svg.getBoundingClientRect(), x = ((e.clientX - r.left) / r.width) * g.W;
      const i = Math.max(0, Math.min(g.n - 1, Math.round(((x - g.m.l) / (g.W - g.m.l - g.m.r)) * (g.n - 1))));
      const gl = svg.querySelector(".guide"); gl.setAttribute("x1", g.X(i)); gl.setAttribute("x2", g.X(i));
      const rows = g.ser.filter((s) => !st.off.has(g.key + s.name) && s.v[i] != null).sort((a, b) => b.v[i] - a.v[i]);
      tip.innerHTML = `<b>ปี ${Y[i]}</b><br>` + (rows.map((s) => `${esc(s.name)}: ${fm(s.v[i])}%`).join("<br>") || "ไม่มีข้อมูล");
      tip.hidden = false; tip.style.left = Math.min(e.clientX + 14, innerWidth - 250) + "px"; tip.style.top = e.clientY + 14 + "px";
    });
    box.addEventListener("pointerleave", () => (tip.hidden = true));
  }
  window.addEventListener("load", () => { render(); setup(); });
})();
