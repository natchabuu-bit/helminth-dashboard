/* แดชบอร์ดผลตรวจพยาธิ — ไม่มีไลบรารีภายนอก แก้ค่าตั้งต้นที่ CONFIG ด้านล่าง */
const CONFIG = {
  title: "ผลตรวจพยาธิในเด็กถิ่นทุรกันดาร เขตสุขภาพที่ 2",
  minSample: 30, // โรงเรียนที่ส่งตรวจน้อยกว่านี้ไม่นำมาจัดอันดับ "ควรติดตาม" (กันตัวเลขแกว่งจากกลุ่มตัวอย่างเล็ก)
  topN: 8,
  // ช่วงความชุก (ร้อยละ) เรียงจากน้อยไปมาก; min = ค่าต่ำสุดของช่วง, ink = สีตัวอักษรบนสีนั้น
  bands: [
    { min: -1, label: "ไม่พบ", color: "#c3d0ca", ink: "#1c2b29" },
    { min: 0.001, label: "น้อยกว่า 5%", color: "#8fb3a6", ink: "#1c2b29" },
    { min: 5, label: "5 ถึง 9.9%", color: "#e2b546", ink: "#1c2b29" },
    { min: 10, label: "10 ถึง 19.9%", color: "#d77f2a", ink: "#1c2b29" },
    { min: 20, label: "20% ขึ้นไป", color: "#a8322a", ink: "#ffffff" },
  ],
  speciesColors: { hookworm: "#b2452e", ascaris: "#14867f", whipworm: "#d99a2b", liver_fluke: "#6d4c8f",
    pinworm: "#4f86a8", tapeworm: "#8a8f3a", mif: "#c26b8f", strongyloides: "#6b7a78" },
  footer: "ที่มา: ไฟล์ Excel ผลตรวจพยาธิรายปี · ความชุก = ผู้ติดเชื้อ ÷ ผู้ส่งตรวจ",
};

const D = window.DASHBOARD_DATA;
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const nf = (n) => Math.round(n).toLocaleString("th-TH");
const pct = (a, b) => (b ? (a / b) * 100 : 0);
const p1 = (x) => x.toFixed(1) + "%";
const bandIdx = (p) => CONFIG.bands.reduce((a, b, i) => (p >= b.min ? i : a), 0);
const f = { province: "", amphoe: "", affil: "", q: "", band: null, year: String(D.meta.years[D.meta.years.length - 1]) };
let sort = { key: "prev", dir: -1 }, pts = [];

const COLS = [
  { k: "school", t: "โรงเรียน / ศูนย์", s: 1 }, { k: "tambon", t: "ตำบล", s: 1 }, { k: "amphoe", t: "อำเภอ", s: 1 },
  { k: "province", t: "จังหวัด", s: 1 }, { k: "affil", t: "สังกัด", s: 1 },
  { k: "total", t: "นักเรียนทั้งหมด", n: 1 }, { k: "sent", t: "ส่งตรวจ", n: 1 },
  { k: "cov", t: "ครอบคลุม", n: 1 }, { k: "pos", t: "พบพยาธิ", n: 1 }, { k: "prev", t: "ความชุก", n: 1 },
  { k: "spText", t: "ชนิดที่พบ", s: 1 },
];
const ALLR = D.schools.filter((s) => s.status === "ok").map((s) => {
  const prev = pct(s.pos, s.sent);
  return { ...s, cov: pct(s.sent, s.total), prev, bi: bandIdx(prev),
    spText: D.meta.species.filter((x) => s.sp[x.key]).map((x) => `${x.label} ${s.sp[x.key]}`).join(", ") || "-" };
});
let R = [], MAXPREV = 1;
function setYear(y) { f.year = String(y); R = ALLR.filter((s) => String(s.year) === f.year); MAXPREV = Math.max(1, ...R.map((s) => s.prev)); }
setYear(f.year);

function filtered(skip) {
  const q = f.q.trim();
  return R.filter((s) => (skip === "province" || !f.province || s.province === f.province) &&
    (skip === "amphoe" || !f.amphoe || s.amphoe === f.amphoe) && (skip === "affil" || !f.affil || s.affil === f.affil) &&
    (skip === "band" || f.band === null || s.bi === f.band) && (!q || (s.school + s.tambon).includes(q)));
}
function agg(rows) {
  const t = { total: 0, sent: 0, pos: 0, n: rows.length, sch: 0, sp: {} };
  rows.forEach((s) => { t.total += s.total; t.sent += s.sent; t.pos += s.pos; t.sch += s.pos > 0 ? 1 : 0;
    for (const k in s.sp) t.sp[k] = (t.sp[k] || 0) + s.sp[k]; });
  return t;
}
function groupBars(rows, key) {
  const m = new Map();
  rows.forEach((s) => m.set(s[key], [...(m.get(s[key]) || []), s]));
  return [...m].map(([k, v]) => { const t = agg(v), p = pct(t.pos, t.sent);
    return { label: k, key, p, c: CONFIG.bands[bandIdx(p)].color, v: `${p1(p)} (${nf(t.pos)}/${nf(t.sent)})` }; })
    .sort((a, b) => b.p - a.p);
}
function bars(id, items, sel) {
  const max = Math.max(1, ...items.map((i) => i.p));
  $(id).innerHTML = items.length ? items.map((i) => {
    const inner = `<span>${esc(i.label)}</span><span class="tr"><i style="width:${(i.p / max) * 100}%;background:${i.c}"></i></span><span class="vl">${i.v}</span>`;
    const dim = sel && sel !== i.label ? "dim" : "";
    return i.key ? `<li class="${dim}"><button type="button" class="row" data-f="${i.key}" data-v="${esc(i.label)}">${inner}</button></li>`
      : `<li><div class="row">${inner}</div></li>`;
  }).join("") : "<li>ไม่มีข้อมูล</li>";
}
function options(id, label, values, cur) {
  $(id).innerHTML = `<option value="">${label}</option>` + [...new Set(values)].filter(Boolean)
    .sort((a, b) => a.localeCompare(b, "th")).map((v) => `<option${v === cur ? " selected" : ""}>${esc(v)}</option>`).join("");
}
function sync() {
  options("f-province", "ทุกจังหวัด", R.map((s) => s.province), f.province);
  options("f-amphoe", "ทุกอำเภอ", R.filter((s) => !f.province || s.province === f.province).map((s) => s.amphoe), f.amphoe);
  options("f-affil", "ทุกสังกัด", R.map((s) => s.affil), f.affil);
}
const ring = (p) => { const c = 2 * Math.PI * 46;
  return `<svg viewBox="0 0 120 120" role="img" aria-label="ครอบคลุม ${p1(p)}"><circle class="rb" cx="60" cy="60" r="46"/><circle class="rf" cx="60" cy="60" r="46" stroke-dasharray="${(c * p) / 100} ${c}" transform="rotate(-90 60 60)"/><text class="rt" x="60" y="62">${p.toFixed(0)}%</text><text class="rs" x="60" y="80">ครอบคลุม</text></svg>`; };

function scatter(rows) {
  pts = rows.filter((s) => s.sent > 0).sort((a, b) => a.pos - b.pos);
  if (!pts.length) { $("scatter").innerHTML = '<p class="hint">ไม่มีข้อมูล</p>'; return; }
  const W = 520, H = 300, m = { l: 40, r: 12, t: 12, b: 38 };
  const lx = (v) => Math.log10(Math.max(1, v)), x0 = lx(Math.min(...pts.map((s) => s.sent))) - 0.08,
    x1 = lx(Math.max(...pts.map((s) => s.sent))) + 0.08;
  const ymax = Math.max(25, Math.ceil(Math.max(...pts.map((s) => s.prev)) / 5) * 5);
  const X = (v) => m.l + ((lx(v) - x0) / (x1 - x0 || 1)) * (W - m.l - m.r), Y = (v) => H - m.b - (v / ymax) * (H - m.t - m.b);
  let g = "";
  [0, 5, 10, 20, 30, 40, 50, 60].filter((t) => t <= ymax).forEach((t) => g += `<line class="gl" x1="${m.l}" x2="${W - m.r}" y1="${Y(t)}" y2="${Y(t)}"/><text x="${m.l - 6}" y="${Y(t) + 4}" text-anchor="end">${t}</text>`);
  [10, 30, 100, 300, 1000].filter((t) => lx(t) > x0 && lx(t) < x1).forEach((t) => g += `<text x="${X(t)}" y="${H - m.b + 16}" text-anchor="middle">${t}</text>`);
  g += `<text x="${(W + m.l) / 2}" y="${H - 4}" text-anchor="middle">จำนวนผู้ส่งตรวจ (สเกลลอการิทึม)</text><text x="12" y="${m.t + 4}">%</text>`;
  const dots = pts.map((s, i) => `<circle data-i="${i}" cx="${X(s.sent)}" cy="${Y(s.prev)}" r="${Math.min(15, 3.5 + Math.sqrt(s.pos) * 1.5)}" fill="${CONFIG.bands[s.bi].color}"/>`).join("");
  $("scatter").innerHTML = `<svg viewBox="0 0 ${W} ${H}" aria-hidden="true">${g}${dots}</svg>`;
}
function topList(rows) {
  const t = rows.filter((s) => s.sent >= CONFIG.minSample && s.pos > 0).sort((a, b) => b.prev - a.prev || b.pos - a.pos).slice(0, CONFIG.topN);
  $("top-hint").textContent = `เรียงตามความชุก เฉพาะแห่งที่ส่งตรวจ ${CONFIG.minSample} คนขึ้นไป · คลิกเพื่อดูในตาราง`;
  $("top").innerHTML = t.length ? t.map((s, i) => { const b = CONFIG.bands[s.bi];
    return `<li><button type="button" data-school="${esc(s.school)}"><span class="rk">${i + 1}</span><span class="nm">${esc(s.school)}<small>${s.tambon ? "ต." + esc(s.tambon) + " " : ""}อ.${esc(s.amphoe)} · ${nf(s.pos)}/${nf(s.sent)} คน</small></span><span class="pv" style="background:${b.color};color:${b.ink}">${p1(s.prev)}</span></button></li>`; }).join("")
    : '<li class="hint">ไม่มีโรงเรียนที่เข้าเกณฑ์ตามตัวกรองนี้</li>';
}
function bandBox() {
  const rows = filtered("band"), cnt = CONFIG.bands.map((_, i) => rows.filter((s) => s.bi === i).length);
  $("bandbox").innerHTML = `<div class="stack">${cnt.map((c, i) => c ? `<i style="flex:${c};background:${CONFIG.bands[i].color}" title="${CONFIG.bands[i].label}: ${c} แห่ง"></i>` : "").join("")}</div>
    <div class="chips">${CONFIG.bands.map((b, i) => `<button type="button" class="chip${f.band === i ? " on" : ""}" data-band="${i}" aria-pressed="${f.band === i}"><span class="dot" style="background:${b.color}"></span>${b.label}<b>${cnt[i]}</b></button>`).join("")}</div>
    <p class="hint" style="margin-top:12px">คลิกระดับเพื่อกรองโรงเรียนในทุกส่วนของหน้า</p>`;
}

function render() {
  const T = `${CONFIG.title} ปีงบประมาณ ${f.year}`; document.title = T; $("title").textContent = T;
  const rows = filtered(), t = agg(rows), prev = pct(t.pos, t.sent);
  $("big").innerHTML = `<b>${p1(prev)}</b><span>ความชุกพยาธิ (พบ ${nf(t.pos)} จาก ${nf(t.sent)} คน)</span>`;
  $("ring").innerHTML = ring(pct(t.sent, t.total));
  $("lead").innerHTML = rows.length ? `จาก <b>${nf(t.n)}</b> แห่ง มีนักเรียนส่งตรวจ <b>${nf(t.sent)}</b> คน ในจำนวนนี้พบพยาธิ <b>${nf(t.pos)}</b> คน และพบอย่างน้อย 1 คนใน <b>${nf(t.sch)}</b> แห่ง`
    : "ไม่พบโรงเรียนตามตัวกรองนี้ ลองล้างตัวกรอง";
  $("strip").innerHTML = [[nf(t.total), "นักเรียนทั้งหมด"], [nf(t.sent), "ส่งตรวจ"], [nf(t.n), "โรงเรียน/ศูนย์"], [nf(t.n - t.sch), "แห่งที่ไม่พบเลย"]]
    .map(([b, s]) => `<div><b>${b}</b><span>${s}</span></div>`).join("");

  scatter(rows); topList(rows); bandBox();
  bars("b-amphoe", groupBars(filtered("amphoe"), "amphoe"), f.amphoe);
  bars("b-affil", groupBars(filtered("affil"), "affil"), f.affil);
  const sp = D.meta.species.map((x) => { const n = t.sp[x.key] || 0, p = pct(n, t.sent);
    return { label: x.label, p, c: CONFIG.speciesColors[x.key] || "#14595a", v: `${p1(p)} (${nf(n)})` }; }).sort((a, b) => b.p - a.p);
  bars("b-species", sp);

  const k = sort.key, dir = sort.dir;
  rows.sort((a, b) => (typeof a[k] === "string" ? a[k].localeCompare(b[k], "th") : a[k] - b[k]) * dir);
  $("t-title").textContent = `รายโรงเรียน (${nf(rows.length)} แห่ง)`;
  $("tbl").tHead.innerHTML = "<tr>" + COLS.map((c) => `<th class="${c.n ? "n" : ""}" aria-sort="${c.k === k ? (dir > 0 ? "ascending" : "descending") : "none"}"><button type="button" data-k="${c.k}">${c.t}${c.k === k ? (dir > 0 ? " ▲" : " ▼") : ""}</button></th>`).join("") + "</tr>";
  $("tbl").tBodies[0].innerHTML = rows.map((s) => "<tr>" + COLS.map((c) => {
    const v = s[c.k];
    if (c.k === "prev") return `<td class="n"><span class="pc"><span class="mini"><i style="width:${(v / MAXPREV) * 100}%;background:${CONFIG.bands[s.bi].color}"></i></span>${p1(v)}</span></td>`;
    if (c.k === "cov") return `<td class="n">${p1(v)}</td>`;
    if (c.n) return `<td class="n">${nf(v)}</td>`;
    return `<td${c.k === "spText" ? ' class="sp"' : ""}>${esc(v)}</td>`;
  }).join("") + "</tr>").join("");
  $("tbl")._rows = rows;
  if (typeof renderCompare === "function") renderCompare(ALLR, f, CONFIG, D);
}

function csv() {
  const rows = $("tbl")._rows, q = (v) => `"${String(typeof v === "number" && !Number.isInteger(v) ? v.toFixed(2) : v).replace(/"/g, '""')}"`;
  const blob = new Blob(["\ufeff" + COLS.map((c) => c.t).join(",") + "\n" + rows.map((s) => COLS.map((c) => q(s[c.k])).join(",")).join("\n")], { type: "text/csv;charset=utf-8" });
  const a = Object.assign(document.createElement("a"), { href: URL.createObjectURL(blob), download: "helminth-schools.csv" });
  a.click(); URL.revokeObjectURL(a.href);
}
const toTable = (name) => { f.q = name; $("f-q").value = name; render(); $("tablewrap").scrollIntoView({ behavior: "smooth" }); };

function setup() {
  $("f-year").innerHTML = D.meta.years.map((y) => `<option${String(y) === f.year ? " selected" : ""}>${y}</option>`).join("");
  $("f-year").onchange = (e) => { setYear(e.target.value); f.band = null; sync(); render(); };
  sync();
  $("f-province").onchange = (e) => { f.province = e.target.value; f.amphoe = ""; sync(); render(); };
  $("f-amphoe").onchange = (e) => { f.amphoe = e.target.value; render(); };
  $("f-affil").onchange = (e) => { f.affil = e.target.value; render(); };
  $("f-q").oninput = (e) => { f.q = e.target.value; render(); };
  $("reset").onclick = () => { Object.assign(f, { province: "", amphoe: "", affil: "", q: "", band: null }); $("f-q").value = ""; sync(); render(); };
  $("csv").onclick = csv;
  document.addEventListener("click", (e) => {
    const b = e.target.closest("button"); if (!b) return;
    if (b.dataset.f) { f[b.dataset.f] = f[b.dataset.f] === b.dataset.v ? "" : b.dataset.v; sync(); render(); }
    else if (b.dataset.band) { const i = +b.dataset.band; f.band = f.band === i ? null : i; render(); }
    else if (b.dataset.school) toTable(b.dataset.school);
    else if (b.dataset.k) { const k = b.dataset.k; sort = { key: k, dir: sort.key === k ? -sort.dir : COLS.find((c) => c.k === k).s ? 1 : -1 }; render(); }
  });
  const tip = $("tip"), sc = $("scatter");
  sc.addEventListener("pointermove", (e) => {
    const c = e.target.closest("circle[data-i]"); if (!c) { tip.hidden = true; return; }
    const s = pts[+c.dataset.i];
    tip.innerHTML = `<b>${esc(s.school)}</b><br>อ.${esc(s.amphoe)}<br>ความชุก ${p1(s.prev)} (${nf(s.pos)}/${nf(s.sent)} คน)`;
    tip.hidden = false; tip.style.left = Math.min(e.clientX + 14, innerWidth - 250) + "px"; tip.style.top = e.clientY + 14 + "px";
  });
  sc.addEventListener("pointerleave", () => (tip.hidden = true));
  sc.addEventListener("click", (e) => { const c = e.target.closest("circle[data-i]"); if (c) toTable(pts[+c.dataset.i].school); });
}

const skip = D.schools.filter((s) => s.status !== "ok");
$("quality").querySelector("summary").textContent = `หมายเหตุข้อมูล: ไม่นำ ${skip.length} แถวมาคำนวณ`;
$("q-list").innerHTML = skip.map((s) => `<li>ปี ${s.year}: ${esc(s.school)} (${esc(s.amphoe)}) — ${s.status === "pending" ? "รอผลตรวจ" : "ตัดออก"}${s.reason ? ": " + esc(s.reason) : ""}</li>`).join("");
$("foot").textContent = `${CONFIG.footer} · ไฟล์ต้นทาง ${D.meta.source} · สร้างข้อมูลเมื่อ ${D.meta.built}`;
setup(); render();
